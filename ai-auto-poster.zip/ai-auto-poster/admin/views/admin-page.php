<div class="wrap ai-auto-poster-admin">
    <h1>AI Auto Poster Settings</h1>
    
    <form method="post" action="options.php">
        <?php settings_fields('ai_auto_poster_settings'); ?>
        <?php do_settings_sections('ai_auto_poster_settings'); ?>
        
        <div class="ai-settings-tabs">
            <nav class="nav-tab-wrapper">
                <a href="#api-settings" class="nav-tab nav-tab-active">API Settings</a>
                <a href="#post-settings" class="nav-tab">Post Settings</a>
                <a href="#sources" class="nav-tab">Topic Sources</a>
                <a href="#schedule" class="nav-tab">Schedule</a>
                <a href="#status" class="nav-tab">Status</a>
            </nav>
            
            <div id="api-settings" class="tab-content active">
                <h3>API Configuration</h3>
                <table class="form-table">
                    <tr>
                        <th scope="row">OpenAI API Key</th>
                        <td>
                            <input type="password" name="ai_auto_poster_openai_api_key" value="<?php echo esc_attr(get_option('ai_auto_poster_openai_api_key')); ?>" class="regular-text" />
                            <button type="button" id="test-openai-connection" class="button button-secondary">Test Connection</button>
                            <p class="description">Required for AI content generation. Get your key from <a href="https://openai.com/api/" target="_blank">OpenAI</a>.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">News API Key</th>
                        <td>
                            <input type="password" name="ai_auto_poster_news_api_key" value="<?php echo esc_attr(get_option('ai_auto_poster_news_api_key')); ?>" class="regular-text" />
                            <p class="description">Optional. For trending news topics. Get your key from <a href="https://newsapi.org/" target="_blank">NewsAPI</a>.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">AI Model</th>
                        <td>
                            <select name="ai_auto_poster_model">
                                <option value="gpt-3.5-turbo" <?php selected(get_option('ai_auto_poster_model', 'gpt-3.5-turbo'), 'gpt-3.5-turbo'); ?>>GPT-3.5 Turbo</option>
                                <option value="gpt-4" <?php selected(get_option('ai_auto_poster_model'), 'gpt-4'); ?>>GPT-4</option>
                                <option value="gpt-4-turbo" <?php selected(get_option('ai_auto_poster_model'), 'gpt-4-turbo'); ?>>GPT-4 Turbo</option>
                             </select>
                            <p class="description">Choose the AI model. GPT-4 is more advanced but costs more.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Max Tokens</th>
                        <td>
                            <input type="number" name="ai_auto_poster_max_tokens" value="<?php echo esc_attr(get_option('ai_auto_poster_max_tokens', 1500)); ?>" min="100" max="4000" />
                            <p class="description">Maximum tokens for AI response (affects content length and cost).</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Target Word Count</th>
                        <td>
                            <input type="number" name="ai_auto_poster_word_count" value="<?php echo esc_attr(get_option('ai_auto_poster_word_count', 500)); ?>" min="100" max="2000" />
                            <p class="description">Target word count for generated content.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Content Tone</th>
                        <td>
                            <select name="ai_auto_poster_tone">
                                <option value="professional" <?php selected(get_option('ai_auto_poster_tone', 'professional'), 'professional'); ?>>Professional</option>
                                <option value="casual" <?php selected(get_option('ai_auto_poster_tone'), 'casual'); ?>>Casual</option>
                                <option value="informative" <?php selected(get_option('ai_auto_poster_tone'), 'informative'); ?>>Informative</option>
                                <option value="engaging" <?php selected(get_option('ai_auto_poster_tone'), 'engaging'); ?>>Engaging</option>
                                <option value="conversational" <?php selected(get_option('ai_auto_poster_tone'), 'conversational'); ?>>Conversational</option>
                            </select>
                            <p class="description">The tone and style for generated content.</p>
                        </td>
                    </tr>
                </table>
            </div>
            
          <div id="post-settings" class="tab-content">
    <h3>Post Configuration</h3>
    <table class="form-table">
        <tr>
            <th scope="row">Post Status</th>
            <td>
                <select name="ai_auto_poster_post_status">
                    <option value="draft" <?php selected(get_option('ai_auto_poster_post_status', 'draft'), 'draft'); ?>>Draft</option>
                    <option value="publish" <?php selected(get_option('ai_auto_poster_post_status'), 'publish'); ?>>Publish</option>
                    <option value="pending" <?php selected(get_option('ai_auto_poster_post_status'), 'pending'); ?>>Pending Review</option>
                </select>
                <p class="description">Status for newly created posts.</p>
            </td>
        </tr>
        <tr>
            <th scope="row">Post Author</th>
            <td>
                <select name="ai_auto_poster_author_id">
                    <?php
                    $authors = get_users(array('role__in' => array('administrator', 'editor', 'author')));
                    $selected_author = get_option('ai_auto_poster_author_id', 1);
                    foreach ($authors as $author) {
                        echo '<option value="' . $author->ID . '" ' . selected($selected_author, $author->ID, false) . '>' . esc_html($author->display_name) . '</option>';
                    }
                    ?>
                </select>
                <p class="description">Default author for generated posts.</p>
            </td>
        </tr>
        <tr>
            <th scope="row">Default Categories</th>
            <td>
                <div style="max-height: 200px; overflow-y: auto; border: 1px solid #ddd; padding: 10px;">
                    <?php
                    $categories = get_categories(array('hide_empty' => false));
                    $selected_categories = get_option('ai_auto_poster_categories', array());
                    if (empty($categories)) {
                        echo '<p>No categories found. <a href="' . admin_url('edit-tags.php?taxonomy=category') . '">Create some categories first</a>.</p>';
                    } else {
                        foreach ($categories as $category) {
                            $checked = in_array($category->term_id, (array)$selected_categories) ? 'checked' : '';
                            echo '<label style="display: block; margin-bottom: 5px;">';
                            echo '<input type="checkbox" name="ai_auto_poster_categories[]" value="' . $category->term_id . '" ' . $checked . '> ';
                            echo esc_html($category->name) . ' (' . $category->count . ' posts)';
                            echo '</label>';
                        }
                    }
                    ?>
                </div>
                <p class="description">Select default categories for generated posts.</p>
            </td>
        </tr>
        <tr>
            <th scope="row">Post Type</th>
            <td>
                <select name="ai_auto_poster_post_type">
                    <?php
                    $post_types = get_post_types(array('public' => true), 'objects');
                    $selected_post_type = get_option('ai_auto_poster_post_type', 'post');
                    foreach ($post_types as $post_type) {
                        if ($post_type->name !== 'attachment') {
                            echo '<option value="' . $post_type->name . '" ' . selected($selected_post_type, $post_type->name, false) . '>' . esc_html($post_type->labels->singular_name) . '</option>';
                        }
                    }
                    ?>
                </select>
                <p class="description">Post type for generated content.</p>
            </td>
        </tr>
        <tr>
            <th scope="row">Content Length</th>
            <td>
                <select name="ai_auto_poster_word_count">
                    <option value="500" <?php selected(get_option('ai_auto_poster_word_count', 1000), 500); ?>>Short (500 words)</option>
                    <option value="800" <?php selected(get_option('ai_auto_poster_word_count', 1000), 800); ?>>Medium (800 words)</option>
                    <option value="1000" <?php selected(get_option('ai_auto_poster_word_count', 1000), 1000); ?>>Long (1000 words)</option>
                    <option value="1500" <?php selected(get_option('ai_auto_poster_word_count', 1000), 1500); ?>>Very Long (1500 words)</option>
                    <option value="2000" <?php selected(get_option('ai_auto_poster_word_count', 1000), 2000); ?>>Extra Long (2000 words)</option>
                </select>
                <p class="description">Target length for generated content. Longer content is more detailed and comprehensive.</p>
            </td>
        </tr>
        <tr>
            <th scope="row">Featured Images</th>
            <td>
                <label>
                    <input type="checkbox" name="ai_auto_poster_add_featured_image" value="1" <?php checked(get_option('ai_auto_poster_add_featured_image', 0), 1); ?> />
                    Add featured images to posts automatically
                </label>
                <p class="description">Automatically find and set relevant featured images for generated posts.</p>
            </td>
        </tr>
        <tr>
            <th scope="row">Unsplash API Key</th>
            <td>
                <input type="password" name="ai_auto_poster_unsplash_api_key" value="<?php echo esc_attr(get_option('ai_auto_poster_unsplash_api_key')); ?>" class="regular-text" />
                <p class="description">Get free API key from <a href="https://unsplash.com/developers" target="_blank">Unsplash Developers</a>. Provides high-quality stock photos.</p>
            </td>
        </tr>
        <tr>
            <th scope="row">Pexels API Key</th>
            <td>
                <input type="password" name="ai_auto_poster_pexels_api_key" value="<?php echo esc_attr(get_option('ai_auto_poster_pexels_api_key')); ?>" class="regular-text" />
                <p class="description">Get free API key from <a href="https://www.pexels.com/api/" target="_blank">Pexels API</a>. Backup source for images.</p>
            </td>
        </tr>
    </table>
</div>
            
            <div id="sources" class="tab-content">
                <h3>Topic Sources</h3>
                <table class="form-table">
                    <tr>
                        <th scope="row">Reddit Subreddits</th>
                        <td>
                            <input type="text" name="ai_auto_poster_subreddits" value="<?php echo esc_attr(get_option('ai_auto_poster_subreddits', 'popular,technology,business')); ?>" class="large-text" />
                            <p class="description">Comma-separated list of subreddits to monitor for trending topics.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">RSS Feeds</th>
                        <td>
                            <textarea name="ai_auto_poster_rss_feeds" rows="5" class="large-text" placeholder="https://feeds.feedburner.com/TechCrunch&#10;https://rss.cnn.com/rss/edition.rss&#10;https://feeds.bbci.co.uk/news/rss.xml"><?php echo esc_textarea(get_option('ai_auto_poster_rss_feeds', '')); ?></textarea>
                            <p class="description">One RSS feed URL per line. Example sources provided as placeholder text.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Excluded Keywords</th>
                        <td>
                            <input type="text" name="ai_auto_poster_excluded_keywords" value="<?php echo esc_attr(get_option('ai_auto_poster_excluded_keywords', '')); ?>" class="large-text" placeholder="politics, sports, celebrity" />
                            <p class="description">Topics containing these keywords will be ignored.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Minimum Trend Score</th>
                        <td>
                            <input type="number" name="ai_auto_poster_min_trend_score" value="<?php echo esc_attr(get_option('ai_auto_poster_min_trend_score', 50)); ?>" min="1" max="100" />
                            <p class="description">Minimum score (1-100) required for a topic to be considered for post creation.</p>
                        </td>
                    </tr>
                </table>
            </div>
            
            <div id="schedule" class="tab-content">
                <h3>Posting Schedule</h3>
                <table class="form-table">
                    <tr>
                        <th scope="row">Topic Discovery Frequency</th>
                        <td>
                            <select name="ai_auto_poster_topic_frequency">
                                <option value="hourly" <?php selected(get_option('ai_auto_poster_topic_frequency', 'hourly'), 'hourly'); ?>>Every Hour</option>
                                <option value="twicedaily" <?php selected(get_option('ai_auto_poster_topic_frequency', 'hourly'), 'twicedaily'); ?>>Twice Daily</option>
                                <option value="daily" <?php selected(get_option('ai_auto_poster_topic_frequency', 'hourly'), 'daily'); ?>>Daily</option>
                            </select>
                            <p class="description">How often to search for new trending topics.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Post Creation Frequency</th>
                        <td>
                            <select name="ai_auto_poster_post_frequency">
                                <option value="twicedaily" <?php selected(get_option('ai_auto_poster_post_frequency', 'twicedaily'), 'twicedaily'); ?>>Twice Daily</option>
                                <option value="daily" <?php selected(get_option('ai_auto_poster_post_frequency', 'twicedaily'), 'daily'); ?>>Daily</option>
                                <option value="weekly" <?php selected(get_option('ai_auto_poster_post_frequency', 'twicedaily'), 'weekly'); ?>>Weekly</option>
                            </select>
                            <p class="description">How often to create new posts automatically.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Posts per Session</th>
                        <td>
                            <input type="number" name="ai_auto_poster_posts_per_session" value="<?php echo esc_attr(get_option('ai_auto_poster_posts_per_session', 3)); ?>" min="1" max="10" />
                            <p class="description">Maximum number of posts to create in each scheduled run.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Enable Auto Posting</th>
                        <td>
                            <label>
                                <input type="checkbox" name="ai_auto_poster_enabled" value="1" <?php checked(get_option('ai_auto_poster_enabled', 1), 1); ?> />
                                Enable automatic posting (uncheck to pause without deactivating plugin)
                            </label>
                        </td>
                    </tr>
                </table>
                
                <h4>Manual Actions</h4>
                <p>
                    <button type="button" id="find-topics-now" class="button button-secondary">Find Topics Now</button>
                    <button type="button" id="create-post-now" class="button button-secondary">Create Post Now</button>
                    <button type="button" id="clear-topics" class="button button-secondary">Clear All Topics</button>
                </p>
                <p class="description">Use these buttons to manually trigger actions for testing or immediate needs.</p>
            </div>
            
            <div id="status" class="tab-content">
                <h3>Plugin Status</h3>
                
                <div class="status-grid">
                    <div class="status-card">
                        <h4>Pending Topics</h4>
                        <div class="status-number">
                            <?php
                            global $wpdb;
                            $table_name = $wpdb->prefix . 'ai_auto_poster_topics';
                            $pending_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE status = 'pending'");
                            echo $pending_count ?: '0';
                            ?>
                        </div>
                        <p class="status-description">Topics ready for content creation</p>
                    </div>
                    
                    <div class="status-card">
                        <h4>Posts Created</h4>
                        <div class="status-number">
                            <?php
                            $used_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE status = 'used'");
                            echo $used_count ?: '0';
                            ?>
                        </div>
                        <p class="status-description">Total posts generated by AI</p>
                    </div>
                    
                    <div class="status-card">
                        <h4>Next Topic Search</h4>
                        <div class="status-text">
                            <?php
                            $next_topic_search = wp_next_scheduled('ai_auto_poster_find_topics_cron');
                            if ($next_topic_search) {
                                echo date('M j, Y H:i', $next_topic_search);
                            } else {
                                echo '<span style="color: #d63638;">Not scheduled</span>';
                            }
                            ?>
                        </div>
                    </div>
                    
                    <div class="status-card">
                        <h4>Next Post Creation</h4>
                        <div class="status-text">
                            <?php
                            $next_post_creation = wp_next_scheduled('ai_auto_poster_create_posts_cron');
                            if ($next_post_creation) {
                                echo date('M j, Y H:i', $next_post_creation);
                            } else {
                                echo '<span style="color: #d63638;">Not scheduled</span>';
                            }
                            ?>
                        </div>
                    </div>
                </div>
                
                <h4>Recent Topics</h4>
                <div class="recent-topics">
                    <?php
                    $recent_topics = $wpdb->get_results(
                        "SELECT * FROM $table_name ORDER BY created_at DESC LIMIT 10", 
                        ARRAY_A
                    );
                    if ($recent_topics) {
                        echo '<table class="wp-list-table widefat striped">';
                        echo '<thead><tr><th>Topic</th><th>Keywords</th><th>Score</th><th>Status</th><th>Created</th><th>Actions</th></tr></thead>';
                        echo '<tbody>';
                        foreach ($recent_topics as $topic) {
                            echo '<tr>';
                            echo '<td><strong>' . esc_html(substr($topic['topic'], 0, 60)) . (strlen($topic['topic']) > 60 ? '...' : '') . '</strong></td>';
                            echo '<td>' . esc_html(substr($topic['keywords'], 0, 40)) . (strlen($topic['keywords']) > 40 ? '...' : '') . '</td>';
                            echo '<td><span class="trend-score">' . $topic['trend_score'] . '</span></td>';
                            echo '<td><span class="status-badge status-' . $topic['status'] . '">' . ucfirst($topic['status']) . '</span></td>';
                            echo '<td>' . date('M j, H:i', strtotime($topic['created_at'])) . '</td>';
                            echo '<td>';
                            if ($topic['status'] == 'pending') {
                                echo '<button type="button" class="button button-small create-post-from-topic" data-topic-id="' . $topic['id'] . '">Create Post</button> ';
                            }
                            echo '<button type="button" class="button button-small button-link-delete delete-topic" data-topic-id="' . $topic['id'] . '">Delete</button>';
                            echo '</td>';
                            echo '</tr>';
                        }
                        echo '</tbody></table>';
                    } else {
                        echo '<div class="notice notice-info"><p>No topics found yet. Click "Find Topics Now" to get started.</p></div>';
                    }
                    ?>
                </div>
            </div>
        </div>
        
        <?php submit_button('Save Settings', 'primary', 'submit', true, array('id' => 'save-settings-btn')); ?>
    </form>
</div>

<script>
jQuery(document).ready(function($) {
    // Tab switching functionality
    $('.nav-tab').click(function(e) {
        e.preventDefault();
        var target = $(this).attr('href');
        
        $('.nav-tab').removeClass('nav-tab-active');
        $(this).addClass('nav-tab-active');
        
        $('.tab-content').removeClass('active');
        $(target).addClass('active');
        
        // Save active tab to localStorage
        localStorage.setItem('ai_auto_poster_active_tab', target);
    });
    
    // Restore active tab from localStorage
    var activeTab = localStorage.getItem('ai_auto_poster_active_tab');
    if (activeTab) {
        $('.nav-tab[href="' + activeTab + '"]').click();
    }
});
</script>


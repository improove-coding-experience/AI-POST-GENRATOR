(function ($) {
  "use strict";

  $(document).ready(function () {
    // Check if required variables are available
    if (typeof ai_auto_poster_ajax === "undefined") {
      console.error("AI Auto Poster: AJAX variables not loaded properly");
      showNotice(
        "Plugin JavaScript error: AJAX variables not loaded. Please refresh the page.",
        "error"
      );
      return;
    }

    // Initialize all functionality
    initTabs();
    initFormValidation();
    initManualActions();
    initAutoSave();
    initStatusUpdates();
    initApiTesting();
    initTopicActions();
  });

  /**
   * Initialize tab switching functionality
   */
  function initTabs() {
    $(".nav-tab").click(function (e) {
      e.preventDefault();
      var target = $(this).attr("href");

      $(".nav-tab").removeClass("nav-tab-active");
      $(this).addClass("nav-tab-active");

      $(".tab-content").removeClass("active");
      $(target).addClass("active");

      // Save active tab to localStorage
      localStorage.setItem("ai_auto_poster_active_tab", target);
    });

    // Restore active tab from localStorage
    var activeTab = localStorage.getItem("ai_auto_poster_active_tab");
    if (activeTab && $(activeTab).length) {
      $('.nav-tab[href="' + activeTab + '"]').click();
    }
  }

  /**
   * Initialize form validation
   */
  function initFormValidation() {
    // API key validation
    $('input[name="ai_auto_poster_openai_api_key"]').on("blur", function () {
      var apiKey = $(this).val();
      if (apiKey && !apiKey.startsWith("sk-")) {
        showNotice('OpenAI API key should start with "sk-"', "warning");
      }
    });

    $('input[name="ai_auto_poster_news_api_key"]').on("blur", function () {
      var apiKey = $(this).val();
      if (apiKey && apiKey.length !== 32) {
        showNotice("News API key should be 32 characters long", "warning");
      }
    });

    // Numeric input validation
    $('input[type="number"]').on("input", function () {
      var min = parseInt($(this).attr("min"));
      var max = parseInt($(this).attr("max"));
      var val = parseInt($(this).val());

      if (min && val < min) {
        $(this).val(min);
        showNotice("Value adjusted to minimum: " + min, "warning");
      } else if (max && val > max) {
        $(this).val(max);
        showNotice("Value adjusted to maximum: " + max, "warning");
      }
    });

    // Subreddit validation
    $('input[name="ai_auto_poster_subreddits"]').on("blur", function () {
      var subreddits = $(this).val().split(",");
      var validPattern = /^[a-zA-Z0-9_]+$/;
      var invalid = [];

      subreddits.forEach(function (sub) {
        sub = sub.trim();
        if (sub && !validPattern.test(sub)) {
          invalid.push(sub);
        }
      });

      if (invalid.length > 0) {
        showNotice("Invalid subreddit names: " + invalid.join(", "), "warning");
      }
    });
  }

  /**
   * Initialize manual action buttons
   */
  function initManualActions() {
    $("#find-topics-now").click(function () {
      var button = $(this);
      var originalText = button.text();

      button.prop("disabled", true).text("Finding Topics...");

      $.post(ai_auto_poster_ajax.ajax_url, {
        action: "ai_auto_poster_find_topics_manual",
        nonce: ai_auto_poster_ajax.nonce,
      })
        .done(function (response) {
          if (response.success) {
            showNotice(
              "Topic search completed! Found " +
                (response.data.count || 0) +
                " new topics.",
              "success"
            );
            setTimeout(function () {
              location.reload();
            }, 2000);
          } else {
            showNotice("Error: " + response.data, "error");
          }
        })
        .fail(function (xhr, status, error) {
          console.error("AJAX Error:", xhr.responseText);
          showNotice("Network error: " + error, "error");
        })
        .always(function () {
          button.prop("disabled", false).text(originalText);
        });
    });

    $("#create-post-now").click(function () {
      var button = $(this);
      var originalText = button.text();

      button.prop("disabled", true).text("Creating Post...");

      $.post(ai_auto_poster_ajax.ajax_url, {
        action: "ai_auto_poster_create_post_manual",
        nonce: ai_auto_poster_ajax.nonce,
      })
        .done(function (response) {
          if (response.success) {
            var message = "Post creation completed!";
            if (response.data.created) {
              message += " Created " + response.data.created + " post(s).";
            }
            showNotice(message, "success");
            setTimeout(function () {
              location.reload();
            }, 2000);
          } else {
            showNotice("Error: " + response.data, "error");
          }
        })
        .fail(function (xhr, status, error) {
          console.error("AJAX Error:", xhr.responseText);
          showNotice("Network error: " + error, "error");
        })
        .always(function () {
          button.prop("disabled", false).text(originalText);
        });
    });

    $("#clear-topics").click(function () {
      if (
        confirm(
          "Are you sure you want to clear all topics? This action cannot be undone."
        )
      ) {
        var button = $(this);
        var originalText = button.text();

        button.prop("disabled", true).text("Clearing...");

        $.post(ai_auto_poster_ajax.ajax_url, {
          action: "ai_auto_poster_clear_topics",
          nonce: ai_auto_poster_ajax.nonce,
        })
          .done(function (response) {
            if (response.success) {
              showNotice("All topics cleared successfully!", "success");
              setTimeout(function () {
                location.reload();
              }, 2000);
            } else {
              showNotice("Error: " + response.data, "error");
            }
          })
          .fail(function (xhr, status, error) {
            console.error("AJAX Error:", xhr.responseText);
            showNotice("Network error: " + error, "error");
          })
          .always(function () {
            button.prop("disabled", false).text(originalText);
          });
      }
    });
  }

  /**
   * Initialize auto-save functionality
   */
  function initAutoSave() {
    var saveTimeout;

    $(".form-table input, .form-table select, .form-table textarea").on(
      "change input",
      function () {
        clearTimeout(saveTimeout);

        // Show saving indicator
        if (!$(".auto-save-indicator").length) {
          $("#save-settings-btn").after(
            '<span class="auto-save-indicator" style="margin-left: 10px; color: #666;">Changes detected...</span>'
          );
        }

        saveTimeout = setTimeout(function () {
          $(".auto-save-indicator")
            .text("Ready to save")
            .css("color", "#00a32a");
        }, 1000);
      }
    );

    // Remove indicator when form is submitted
    $("form").on("submit", function () {
      $(".auto-save-indicator").remove();
    });

    // Character counter for RSS feeds
    $('textarea[name="ai_auto_poster_rss_feeds"]').after(
      '<div class="char-counter" style="font-size: 11px; color: #666; margin-top: 5px;"></div>'
    );

    $('textarea[name="ai_auto_poster_rss_feeds"]')
      .on("input", function () {
        var lines = $(this)
          .val()
          .split("\n")
          .filter(function (line) {
            return line.trim() !== "";
          });
        $(this)
          .next(".char-counter")
          .text(lines.length + " RSS feed(s) entered");
      })
      .trigger("input");
  }

  /**
   * Initialize status updates
   */
  function initStatusUpdates() {
    function updateStatus() {
      $.post(ai_auto_poster_ajax.ajax_url, {
        action: "ai_auto_poster_get_status",
        nonce: ai_auto_poster_ajax.nonce,
      })
        .done(function (response) {
          if (response.success && $("#status").hasClass("active")) {
            // Update status cards
            $(".status-number").each(function (index) {
              var newValue = response.data.counts[index];
              if (newValue && $(this).text() !== newValue) {
                $(this).fadeOut(200, function () {
                  $(this).text(newValue).fadeIn(200);
                });
              }
            });
          }
        })
        .fail(function (xhr, status, error) {
          console.log("Status update failed:", error);
        });
    }

    // Update status every 30 seconds if on status tab
    setInterval(function () {
      if ($("#status").hasClass("active")) {
        updateStatus();
      }
    }, 30000);
  }

  /**
   * Initialize API testing
   */
  function initApiTesting() {
    $("#test-openai-connection").click(function () {
      var button = $(this);
      var apiKey = $('input[name="ai_auto_poster_openai_api_key"]').val();
      var originalText = button.text();

      if (!apiKey) {
        showNotice("Please enter OpenAI API key first.", "error");
        return;
      }

      button.prop("disabled", true).text("Testing...");

      $.post(ai_auto_poster_ajax.ajax_url, {
        action: "ai_auto_poster_test_openai",
        api_key: apiKey,
        nonce: ai_auto_poster_ajax.nonce,
      })
        .done(function (response) {
          if (response.success) {
            showNotice("OpenAI API connection successful!", "success");
          } else {
            showNotice(
              "OpenAI API connection failed: " + response.data,
              "error"
            );
          }
        })
        .fail(function (xhr, status, error) {
          console.error("AJAX Error:", xhr.responseText);
          showNotice("Error testing OpenAI API connection: " + error, "error");
        })
        .always(function () {
          button.prop("disabled", false).text(originalText);
        });
    });
  }

  /**
   * Initialize individual topic actions
   */
  function initTopicActions() {
    $(document).on("click", ".create-post-from-topic", function () {
      var topicId = $(this).data("topic-id");
      var button = $(this);
      var originalText = button.text();

      button.prop("disabled", true).text("Creating...");

      $.post(ai_auto_poster_ajax.ajax_url, {
        action: "ai_auto_poster_create_post_from_topic",
        topic_id: topicId,
        nonce: ai_auto_poster_ajax.nonce,
      })
        .done(function (response) {
          if (response.success) {
            var message = "Post created from topic!";
            if (response.data.edit_link) {
              message +=
                ' <a href="' +
                response.data.edit_link +
                '" target="_blank">Edit Post</a>';
            }
            showNotice(message, "success");
            setTimeout(function () {
              location.reload();
            }, 3000);
          } else {
            showNotice("Error creating post: " + response.data, "error");
          }
        })
        .fail(function (xhr, status, error) {
          console.error("AJAX Error:", xhr.responseText);
          showNotice("Network error: " + error, "error");
        })
        .always(function () {
          button.prop("disabled", false).text(originalText);
        });
    });

    $(document).on("click", ".delete-topic", function () {
      if (confirm("Are you sure you want to delete this topic?")) {
        var topicId = $(this).data("topic-id");
        var row = $(this).closest("tr");

        $.post(ai_auto_poster_ajax.ajax_url, {
          action: "ai_auto_poster_delete_topic",
          topic_id: topicId,
          nonce: ai_auto_poster_ajax.nonce,
        })
          .done(function (response) {
            if (response.success) {
              row.fadeOut(function () {
                row.remove();
              });
              showNotice("Topic deleted successfully!", "success");
            } else {
              showNotice("Error deleting topic: " + response.data, "error");
            }
          })
          .fail(function (xhr, status, error) {
            console.error("AJAX Error:", xhr.responseText);
            showNotice("Network error: " + error, "error");
          });
      }
    });
  }

  /**
   * Show notification message
   */
  function showNotice(message, type) {
    var noticeClass = "notice-" + type;
    var notice = $(
      '<div class="notice ' +
        noticeClass +
        ' is-dismissible"><p>' +
        message +
        '</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>'
    );

    $(".ai-auto-poster-admin h1").after(notice);

    // Handle dismiss button
    notice.find(".notice-dismiss").click(function () {
      notice.fadeOut(function () {
        notice.remove();
      });
    });

    // Auto-dismiss after 5 seconds for success/warning
    if (type !== "error") {
      setTimeout(function () {
        if (notice.is(":visible")) {
          notice.fadeOut(function () {
            notice.remove();
          });
        }
      }, 5000);
    }

    // Scroll to notice
    $("html, body").animate(
      {
        scrollTop: notice.offset().top - 100,
      },
      500
    );
  }

  /**
   * Global AJAX error handler
   */
  $(document).ajaxError(function (event, xhr, settings) {
    // Only handle our plugin's AJAX requests
    if (
      settings.url &&
      settings.url.indexOf("admin-ajax.php") !== -1 &&
      settings.data &&
      settings.data.indexOf("ai_auto_poster") !== -1
    ) {
      console.error("AJAX Error Details:", {
        status: xhr.status,
        statusText: xhr.statusText,
        responseText: xhr.responseText,
        settings: settings,
      });
    }
  });

  /**
   * Prevent double form submission
   */
  $("form").on("submit", function () {
    var submitButton = $(this).find('input[type="submit"]');
    submitButton.prop("disabled", true);

    setTimeout(function () {
      submitButton.prop("disabled", false);
    }, 3000);
  });
})(jQuery);

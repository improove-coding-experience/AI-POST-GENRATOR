<?php

class AI_Auto_Poster_Admin_Settings {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        
        // AJAX handlers
        add_action('wp_ajax_ai_auto_poster_find_topics_manual', array($this, 'ajax_find_topics'));
        add_action('wp_ajax_ai_auto_poster_create_post_manual', array($this, 'ajax_create_post'));
        add_action('wp_ajax_ai_auto_poster_test_openai', array($this, 'ajax_test_openai'));
        add_action('wp_ajax_ai_auto_poster_get_status', array($this, 'ajax_get_status'));
        add_action('wp_ajax_ai_auto_poster_clear_topics', array($this, 'ajax_clear_topics'));
        add_action('wp_ajax_ai_auto_poster_create_post_from_topic', array($this, 'ajax_create_post_from_topic'));
        add_action('wp_ajax_ai_auto_poster_delete_topic', array($this, 'ajax_delete_topic'));
    }
    
    public function add_admin_menu() {
        add_options_page(
            'AI Auto Poster Settings',
            'AI Auto Poster',
            'manage_options',
            'ai-auto-poster',
            array($this, 'settings_page')
        );
    }
    
    public function enqueue_admin_scripts($hook_suffix) {
        if ($hook_suffix !== 'settings_page_ai-auto-poster') {
            return;
        }
        
        // Enqueue admin script and style
        wp_enqueue_script('ai-auto-poster-admin', AI_AUTO_POSTER_PLUGIN_URL . 'admin/js/admin-script.js', array('jquery'), AI_AUTO_POSTER_VERSION, true);
        wp_enqueue_style('ai-auto-poster-admin', AI_AUTO_POSTER_PLUGIN_URL . 'admin/css/admin-style.css', array(), AI_AUTO_POSTER_VERSION);
        
        // Localize script with AJAX data
        wp_localize_script('ai-auto-poster-admin', 'ai_auto_poster_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ai_auto_poster_nonce')
        ));
    }
    
    public function register_settings() {
        // API Settings
        register_setting('ai_auto_poster_settings', 'ai_auto_poster_openai_api_key');
        register_setting('ai_auto_poster_settings', 'ai_auto_poster_news_api_key');
        register_setting('ai_auto_poster_settings', 'ai_auto_poster_model');
        register_setting('ai_auto_poster_settings', 'ai_auto_poster_max_tokens');
        register_setting('ai_auto_poster_settings', 'ai_auto_poster_word_count');
        register_setting('ai_auto_poster_settings', 'ai_auto_poster_tone');
        
        // Image Settings
        register_setting('ai_auto_poster_settings', 'ai_auto_poster_add_featured_image');
        register_setting('ai_auto_poster_settings', 'ai_auto_poster_unsplash_api_key');
        register_setting('ai_auto_poster_settings', 'ai_auto_poster_pexels_api_key');
        
        // Post Settings
        register_setting('ai_auto_poster_settings', 'ai_auto_poster_post_status');
        register_setting('ai_auto_poster_settings', 'ai_auto_poster_author_id');
        register_setting('ai_auto_poster_settings', 'ai_auto_poster_categories');
        register_setting('ai_auto_poster_settings', 'ai_auto_poster_post_type');
        
        // Topic Sources
        register_setting('ai_auto_poster_settings', 'ai_auto_poster_subreddits');
        register_setting('ai_auto_poster_settings', 'ai_auto_poster_rss_feeds');
        register_setting('ai_auto_poster_settings', 'ai_auto_poster_excluded_keywords');
        register_setting('ai_auto_poster_settings', 'ai_auto_poster_min_trend_score');
        
        // Schedule Settings
        register_setting('ai_auto_poster_settings', 'ai_auto_poster_topic_frequency');
        register_setting('ai_auto_poster_settings', 'ai_auto_poster_post_frequency');
        register_setting('ai_auto_poster_settings', 'ai_auto_poster_posts_per_session');
        register_setting('ai_auto_poster_settings', 'ai_auto_poster_enabled');
    }
    
    public function settings_page() {
        include AI_AUTO_POSTER_PLUGIN_DIR . 'admin/views/admin-page.php';
    }
    
    // AJAX Handlers
    public function ajax_find_topics() {
        if (!wp_verify_nonce($_POST['nonce'], 'ai_auto_poster_nonce')) {
            wp_send_json_error('Invalid nonce');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $topic_finder = new AI_Topic_Finder();
        $topics = $topic_finder->find_trending_topics();
        
        if (empty($topics)) {
            wp_send_json_error('No topics found');
        }
        
        wp_send_json_success(array('count' => count($topics)));
    }
    
    public function ajax_create_post() {
        if (!wp_verify_nonce($_POST['nonce'], 'ai_auto_poster_nonce')) {
            wp_send_json_error('Invalid nonce');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        // Get pending topics
        global $wpdb;
        $table_name = $wpdb->prefix . 'ai_auto_poster_topics';
        $topics = $wpdb->get_results("SELECT * FROM {$table_name} WHERE status = 'pending' ORDER BY trend_score DESC LIMIT 1");
        
        if (empty($topics)) {
            wp_send_json_error('No pending topics available');
        }
        
        $topic = $topics[0];
        $content_generator = new AI_Content_Generator();
        $content_data = $content_generator->generate_content($topic->topic, $topic->keywords);
        
        if (!$content_data) {
            wp_send_json_error('Failed to generate content');
        }
        
        // Create post
        $post_data = array(
            'post_title' => $content_data['title'],
            'post_content' => $content_data['content'],
            'post_status' => get_option('ai_auto_poster_post_status', 'draft'),
            'post_author' => get_option('ai_auto_poster_author_id', get_current_user_id()),
            'post_type' => get_option('ai_auto_poster_post_type', 'post')
        );
        
        $post_id = wp_insert_post($post_data);
        
        if (is_wp_error($post_id)) {
            wp_send_json_error('Failed to create post');
        }
        
        // Mark topic as used
        $wpdb->update(
            $table_name,
            array('status' => 'used', 'used_at' => current_time('mysql')),
            array('id' => $topic->id)
        );
        
        // Add categories
        $categories = get_option('ai_auto_poster_categories', array());
        if (!empty($categories)) {
            wp_set_post_categories($post_id, $categories);
        } 
        
        wp_send_json_success(array('created' => 1));
    }
    
    public function ajax_test_openai() {
        if (!wp_verify_nonce($_POST['nonce'], 'ai_auto_poster_nonce')) {
            wp_send_json_error('Invalid nonce');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $api_key = sanitize_text_field($_POST['api_key']);
        
        if (empty($api_key)) {
            wp_send_json_error('API key is required');
        }
        
        $headers = array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type' => 'application/json',
        );
        
        $body = array(
            'model' => 'gpt-3.5-turbo',
            'messages' => array(
                array(
                    'role' => 'user',
                    'content' => 'Test'
                )
            ),
            'max_tokens' => 10
        );
        
        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
            'headers' => $headers,
            'body' => json_encode($body),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            wp_send_json_error('Connection failed: ' . $response->get_error_message());
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        
        if ($status_code === 200) {
            wp_send_json_success('API connection successful');
        } else {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            $error = isset($body['error']['message']) ? $body['error']['message'] : 'Unknown error';
            wp_send_json_error('API error: ' . $error);
        }
    }
    
    public function ajax_get_status() {
        if (!wp_verify_nonce($_POST['nonce'], 'ai_auto_poster_nonce')) {
            wp_send_json_error('Invalid nonce');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'ai_auto_poster_topics';
        
        $pending = $wpdb->get_var("SELECT COUNT(*) FROM {$table_name} WHERE status = 'pending'");
        $used = $wpdb->get_var("SELECT COUNT(*) FROM {$table_name} WHERE status = 'used'");
        
        wp_send_json_success(array(
            'counts' => array($pending, $used)
        ));
    }
    
    public function ajax_clear_topics() {
        if (!wp_verify_nonce($_POST['nonce'], 'ai_auto_poster_nonce')) {
            wp_send_json_error('Invalid nonce');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'ai_auto_poster_topics';
        $wpdb->query("DELETE FROM {$table_name}");
        
        wp_send_json_success('Topics cleared');
    }
    
    public function ajax_create_post_from_topic() {
        if (!wp_verify_nonce($_POST['nonce'], 'ai_auto_poster_nonce')) {
            wp_send_json_error('Invalid nonce');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $topic_id = intval($_POST['topic_id']);
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'ai_auto_poster_topics';
        $topic = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE id = %d", $topic_id));
        
        if (!$topic) {
            wp_send_json_error('Topic not found');
        }
        
        // Generate content and create post (similar to ajax_create_post)
        $content_generator = new AI_Content_Generator();
        $content_data = $content_generator->generate_content($topic->topic, $topic->keywords);
        
        if (!$content_data) {
            wp_send_json_error('Failed to generate content');
        }
        
        $post_data = array(
            'post_title' => $content_data['title'],
            'post_content' => $content_data['content'],
            'post_status' => get_option('ai_auto_poster_post_status', 'draft'),
            'post_author' => get_option('ai_auto_poster_author_id', get_current_user_id()),
            'post_type' => get_option('ai_auto_poster_post_type', 'post')
        );
        
        $post_id = wp_insert_post($post_data);
        
        if (is_wp_error($post_id)) {
            wp_send_json_error('Failed to create post');
        }
        
        // Mark topic as used
        $wpdb->update(
            $table_name,
            array('status' => 'used', 'used_at' => current_time('mysql')),
            array('id' => $topic_id)
        );
        
        wp_send_json_success(array(
            'edit_link' => admin_url('post.php?post=' . $post_id . '&action=edit')
        ));
    }
    
    public function ajax_delete_topic() {
        if (!wp_verify_nonce($_POST['nonce'], 'ai_auto_poster_nonce')) {
            wp_send_json_error('Invalid nonce');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $topic_id = intval($_POST['topic_id']);
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'ai_auto_poster_topics';
        $result = $wpdb->delete($table_name, array('id' => $topic_id));
        
        if ($result === false) {
            wp_send_json_error('Failed to delete topic');
        }
        
        wp_send_json_success('Topic deleted');
    }
}
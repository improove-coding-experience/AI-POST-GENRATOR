<?php
class AI_Content_Generator {
    
    private $openai_api_key;
    private $api_endpoint = 'https://api.openai.com/v1/chat/completions';
    
    public function __construct() {
        $this->openai_api_key = get_option('ai_auto_poster_openai_api_key', '');
    }
    
    public function generate_content($topic, $keywords) {
        if (empty($this->openai_api_key)) {
            return $this->generate_enhanced_basic_content($topic, $keywords);
        }
        
        return $this->generate_ai_content($topic, $keywords);
    }
    
    private function generate_ai_content($topic, $keywords) {
        $prompt = $this->create_enhanced_prompt($topic, $keywords);
        
        $headers = array(
            'Authorization' => 'Bearer ' . $this->openai_api_key,
            'Content-Type' => 'application/json',
        );
        
        $body = array(
            'model' => get_option('ai_auto_poster_model', 'gpt-3.5-turbo'),
            'messages' => array(
                array(
                    'role' => 'system',
                    'content' => 'You are a professional content writer and SEO expert. Create comprehensive, engaging blog posts with detailed sections, practical examples, and actionable insights. Structure content with clear headings and subheadings.'
                ),
                array(
                    'role' => 'user',
                    'content' => $prompt
                )
            ),
            'max_tokens' => get_option('ai_auto_poster_max_tokens', 2500),
            'temperature' => 0.7
        );
        
        $response = wp_remote_post($this->api_endpoint, array(
            'headers' => $headers,
            'body' => json_encode($body),
            'timeout' => 90
        ));
        
        if (is_wp_error($response)) {
            return $this->generate_enhanced_basic_content($topic, $keywords);
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (isset($data['choices'][0]['message']['content'])) {
            $content = $data['choices'][0]['message']['content'];
            $parsed_content = $this->parse_ai_content($content, $topic);
            
            // Add featured image if enabled
            if (get_option('ai_auto_poster_add_featured_image', 0)) {
                $parsed_content['featured_image'] = $this->find_relevant_image($topic, $keywords);
            }
            
            return $parsed_content;
        }
        
        return $this->generate_enhanced_basic_content($topic, $keywords);
    }
    
    private function create_enhanced_prompt($topic, $keywords) {
        $word_count = max(800, get_option('ai_auto_poster_word_count', 1000));
        $tone = get_option('ai_auto_poster_tone', 'professional');
        
        $prompt = "Write a comprehensive {$word_count}-word blog post about: {$topic}\n\n";
        $prompt .= "Keywords to naturally include: {$keywords}\n\n";
        $prompt .= "Tone: {$tone}\n\n";
        
        $prompt .= "REQUIREMENTS:\n";
        $prompt .= "1. Create an engaging, click-worthy title\n";
        $prompt .= "2. Start with a compelling introduction that hooks the reader\n";
        $prompt .= "3. Use clear H2 and H3 headings to structure the content\n";
        $prompt .= "4. Include at least 5-7 substantial paragraphs with detailed explanations\n";
        $prompt .= "5. Add practical examples, tips, or actionable insights\n";
        $prompt .= "6. Include relevant statistics or data points when appropriate\n";
        $prompt .= "7. End with a strong conclusion and call-to-action\n";
        $prompt .= "8. Make it SEO-friendly with natural keyword placement\n\n";
        
        $prompt .= "FORMAT:\n";
        $prompt .= "TITLE: [Engaging blog post title]\n";
        $prompt .= "CONTENT: [Full blog post with HTML formatting including h2, h3 tags, and proper paragraphs]\n\n";
        
        $prompt .= "Make the content informative, engaging, and valuable to readers. Include specific details and examples.";
        
        return $prompt;
    }
    
    private function parse_ai_content($content, $topic) {
        $lines = explode("\n", $content);
        $title = '';
        $post_content = '';
        $content_started = false;
        
        foreach ($lines as $line) {
            $line = trim($line);
            
            if (strpos($line, 'TITLE:') === 0) {
                $title = trim(str_replace('TITLE:', '', $line));
            } elseif (strpos($line, 'CONTENT:') === 0) {
                $post_content .= trim(str_replace('CONTENT:', '', $line)) . "\n\n";
                $content_started = true;
            } elseif ($content_started && !empty($line)) {
                $post_content .= $line . "\n\n";
            }
        }
        
        // Fallback if parsing fails
        if (empty($title)) {
            $title = $this->generate_title_from_topic($topic);
        }
        
        if (empty($post_content)) {
            $post_content = $content;
        }
        
        return array(
            'title' => $title,
            'content' => wpautop($post_content)
        );
    }
    
    private function generate_enhanced_basic_content($topic, $keywords) {
        $title = $this->generate_title_from_topic($topic);
        
        $content = "<h2>Introduction</h2>\n";
        $content .= "<p>In today's rapidly evolving digital landscape, <strong>{$topic}</strong> has emerged as a critical factor that's reshaping industries and influencing countless decisions worldwide. Understanding this topic is no longer optional—it's essential for anyone looking to stay ahead of the curve.</p>\n\n";
        
        $content .= "<p>This comprehensive guide will explore the various aspects of {$topic}, providing you with actionable insights and practical knowledge that you can apply immediately.</p>\n\n";
        
        if (!empty($keywords)) {
            $keyword_array = array_filter(array_map('trim', explode(', ', $keywords)));
            if (!empty($keyword_array)) {
                $content .= "<h2>Key Areas and Components</h2>\n";
                $content .= "<p>When discussing {$topic}, several important areas come into focus, including <strong>" . implode('</strong>, <strong>', array_slice($keyword_array, 0, 5)) . "</strong>. Each of these components plays a vital role in the overall ecosystem.</p>\n\n";
                
                foreach (array_slice($keyword_array, 0, 3) as $keyword) {
                    $content .= "<h3>" . ucfirst($keyword) . " and Its Impact</h3>\n";
                    $content .= "<p>The role of {$keyword} in relation to {$topic} cannot be understated. This aspect influences decision-making processes and shapes outcomes across multiple sectors. Organizations that understand and leverage {$keyword} effectively often see significant improvements in their results.</p>\n\n";
                }
            }
        }
        
        $content .= "<h2>Current Trends and Developments</h2>\n";
        $content .= "<p>The landscape surrounding {$topic} is constantly evolving, with new developments emerging regularly. Industry experts have identified several key trends that are worth monitoring:</p>\n\n";
        
        $content .= "<ul>\n";
        $content .= "<li>Increased focus on innovation and technological advancement</li>\n";
        $content .= "<li>Growing emphasis on sustainability and long-term planning</li>\n";
        $content .= "<li>Enhanced collaboration between different stakeholders</li>\n";
        $content .= "<li>Integration of data-driven decision making processes</li>\n";
        $content .= "</ul>\n\n";
        
        $content .= "<h2>Practical Applications and Benefits</h2>\n";
        $content .= "<p>Understanding {$topic} offers numerous practical benefits. Organizations and individuals who invest time in mastering this area often experience improved efficiency, better decision-making capabilities, and enhanced competitive advantages.</p>\n\n";
        
        $content .= "<p>Some of the most significant benefits include:</p>\n\n";
        $content .= "<p><strong>Enhanced Strategic Planning:</strong> A deep understanding of {$topic} enables more effective long-term planning and strategic decision-making.</p>\n\n";
        
        $content .= "<p><strong>Improved Risk Management:</strong> Knowledge in this area helps identify potential challenges before they become major issues.</p>\n\n";
        
        $content .= "<p><strong>Better Resource Allocation:</strong> Understanding the key factors allows for more efficient use of available resources.</p>\n\n";
        
        $content .= "<h2>Future Outlook and Recommendations</h2>\n";
        $content .= "<p>Looking ahead, {$topic} will likely continue to evolve and adapt to changing circumstances. Staying informed about developments in this area is crucial for maintaining relevance and competitive advantage.</p>\n\n";
        
        $content .= "<p>We recommend regular monitoring of industry publications, participating in relevant professional development opportunities, and engaging with experts in the field to stay current with the latest developments.</p>\n\n";
        
        $content .= "<h2>Conclusion</h2>\n";
        $content .= "<p>In conclusion, {$topic} represents a significant opportunity for growth and improvement. By understanding the key concepts, staying informed about current trends, and applying practical insights, individuals and organizations can position themselves for success.</p>\n\n";
        
        $content .= "<p>What's your experience with {$topic}? Have you implemented any strategies related to this area? Share your thoughts and experiences in the comments below—we'd love to hear from you and learn about your journey.</p>";
        
        return array(
            'title' => $title,
            'content' => $content,
            'featured_image' => get_option('ai_auto_poster_add_featured_image', 0) ? $this->find_relevant_image($topic, $keywords) : null
        );
    }
    
    private function generate_title_from_topic($topic) {
        $prefixes = array(
            'Understanding',
            'Exploring',
            'The Complete Guide to',
            'Latest Trends in',
            'Everything You Need to Know About',
            'A Deep Dive into',
            'The Future of',
            'Mastering',
            'The Ultimate Guide to'
        );
        
        $prefix = $prefixes[array_rand($prefixes)];
        return $prefix . ' ' . $topic;
    }
    
    private function find_relevant_image($topic, $keywords) {
        // Try Unsplash first
        $unsplash_image = $this->get_unsplash_image($topic, $keywords);
        if ($unsplash_image) {
            return $unsplash_image;
        }
        
        // Fallback to Pexels
        return $this->get_pexels_image($topic, $keywords);
    }
    
    private function get_unsplash_image($topic, $keywords) {
        $unsplash_api_key = get_option('ai_auto_poster_unsplash_api_key', '');
        
        if (empty($unsplash_api_key)) {
            return null;
        }
        
        // Create search query from topic and keywords
        $search_terms = $this->extract_image_keywords($topic . ' ' . $keywords);
        if (empty($search_terms)) {
            return null;
        }
        
        $query = implode(' ', array_slice($search_terms, 0, 3));
        
        $url = "https://api.unsplash.com/photos/random";
        $url .= "?query=" . urlencode($query);
        $url .= "&orientation=landscape";
        $url .= "&client_id=" . $unsplash_api_key;
        
        $response = wp_remote_get($url, array(
            'timeout' => 30,
            'headers' => array(
                'Accept-Version' => 'v1'
            )
        ));
        
        if (is_wp_error($response)) {
            return null;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (isset($data['urls']['regular'])) {
            return array(
                'url' => $data['urls']['regular'],
                'alt_text' => isset($data['alt_description']) ? $data['alt_description'] : $topic,
                'attribution' => isset($data['user']['name']) ? 'Photo by ' . $data['user']['name'] . ' on Unsplash' : 'Photo from Unsplash'
            );
        }
        
        return null;
    }
    
    private function get_pexels_image($topic, $keywords) {
        $pexels_api_key = get_option('ai_auto_poster_pexels_api_key', '');
        
        if (empty($pexels_api_key)) {
            return null;
        }
        
        $search_terms = $this->extract_image_keywords($topic . ' ' . $keywords);
        if (empty($search_terms)) {
            return null;
        }
        
        $query = implode(' ', array_slice($search_terms, 0, 3));
        
        $url = "https://api.pexels.com/v1/search";
        $url .= "?query=" . urlencode($query);
        $url .= "&per_page=1&orientation=landscape";
        
        $response = wp_remote_get($url, array(
            'timeout' => 30,
            'headers' => array(
                'Authorization' => $pexels_api_key
            )
        ));
        
        if (is_wp_error($response)) {
            return null;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (isset($data['photos'][0])) {
            $photo = $data['photos'][0];
            return array(
                'url' => $photo['src']['large'],
                'alt_text' => isset($photo['alt']) ? $photo['alt'] : $topic,
                'attribution' => 'Photo by ' . $photo['photographer'] . ' from Pexels'
            );
        }
        
        return null;
    }
    
    private function extract_image_keywords($text) {
        $text = strtolower($text);
        $text = preg_replace('/[^a-z0-9\s]/', '', $text);
        
        // Remove stop words and very common words
        $stop_words = array('the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'from', 'up', 'about', 'into', 'through', 'during', 'before', 'after', 'above', 'below', 'between', 'among', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'must', 'can', 'shall');
        
        $words = explode(' ', $text);
        $keywords = array();
        
        foreach ($words as $word) {
            $word = trim($word);
            if (strlen($word) > 3 && !in_array($word, $stop_words)) {
                $keywords[] = $word;
            }
        }
        
        return array_unique($keywords);
    }
}
 ?>
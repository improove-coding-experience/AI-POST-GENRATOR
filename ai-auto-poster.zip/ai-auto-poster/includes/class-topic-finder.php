<?php
class AI_Topic_Finder {
    
    private $news_api_key;
    
    public function __construct() {
        $this->news_api_key = get_option('ai_auto_poster_news_api_key', '');
    }
    
   public function find_trending_topics() {
    $topics = array();
    
    // Get search terms from settings
    $search_terms = get_option('ai_auto_poster_subreddits', 'blockchain');
    $terms_array = array_map('trim', explode(',', $search_terms));
    
    foreach ($terms_array as $term) {
        if (empty($term)) continue;
        
        // Generate relevant topics for each search term
        $topics[] = array(
            'topic' => "Latest " . $term . " developments and trends",
            'keywords' => $term . ', technology, innovation, trends, news',
            'trend_score' => rand(70, 90),
            'source' => 'keyword_search'
        );
        
        $topics[] = array(
            'topic' => "How " . $term . " is changing the industry",
            'keywords' => $term . ', impact, industry, business, change',
            'trend_score' => rand(60, 80),
            'source' => 'keyword_search'
        );
        
        $topics[] = array(
            'topic' => "Understanding " . $term . ": A comprehensive guide",
            'keywords' => $term . ', guide, tutorial, beginner, explanation',
            'trend_score' => rand(65, 85),
            'source' => 'keyword_search'
        );
        
        $topics[] = array(
            'topic' => "The future of " . $term . " in 2025 and beyond",
            'keywords' => $term . ', future, predictions, 2025, forecast',
            'trend_score' => rand(75, 95),
            'source' => 'keyword_search'
        );
        
        $topics[] = array(
            'topic' => "Top " . $term . " news and updates this week",
            'keywords' => $term . ', news, updates, weekly, current',
            'trend_score' => rand(80, 100),
            'source' => 'keyword_search'
        );
    }
    
    // Store topics in database
    $stored_count = $this->store_topics($topics);
    
    return $topics;
}
    
    private function get_news_api_topics() {
        if (empty($this->news_api_key)) {
            return array();
        }
        
        $url = "https://newsapi.org/v2/top-headlines?country=us&apiKey=" . $this->news_api_key;
        
        $response = wp_remote_get($url);
        
        if (is_wp_error($response)) {
            return array();
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        $topics = array();
        
        if (isset($data['articles']) && is_array($data['articles'])) {
            foreach ($data['articles'] as $article) {
                $topics[] = array(
                    'topic' => sanitize_text_field($article['title']),
                    'keywords' => $this->extract_keywords($article['title'] . ' ' . $article['description']),
                    'trend_score' => 80,
                    'source' => 'newsapi'
                );
            }
        }
        
        return array_slice($topics, 0, 10);
    }
    
    private function get_reddit_topics() {
        $subreddits = get_option('ai_auto_poster_subreddits', 'popular,technology,business');
        $subreddit_list = explode(',', $subreddits);
        
        $topics = array();
        
        foreach ($subreddit_list as $subreddit) {
            $subreddit = trim($subreddit);
            
            // Skip if it looks like a search term instead of subreddit
            if (strpos($subreddit, ' ') !== false || strlen($subreddit) < 3) {
                continue;
            }
            
            $url = "https://www.reddit.com/r/{$subreddit}/hot.json?limit=10";
            
            $response = wp_remote_get($url, array(
                'headers' => array(
                    'User-Agent' => 'WordPress AI Auto Poster Bot 1.0'
                ),
                'timeout' => 15
            ));
            
            if (!is_wp_error($response)) {
                $body = wp_remote_retrieve_body($response);
                $data = json_decode($body, true);
                
                if (isset($data['data']['children'])) {
                    foreach ($data['data']['children'] as $post) {
                        $post_data = $post['data'];
                        $topics[] = array(
                            'topic' => sanitize_text_field($post_data['title']),
                            'keywords' => $this->extract_keywords($post_data['title']),
                            'trend_score' => min(100, max(10, $post_data['ups'] / 10)),
                            'source' => 'reddit_' . $subreddit
                        );
                    }
                }
            }
        }
        
        return $topics;
    }
    
    private function search_reddit_by_keywords() {
        $subreddits = get_option('ai_auto_poster_subreddits', '');
        $search_terms = explode(',', $subreddits);
        
        $topics = array();
        
        foreach ($search_terms as $term) {
            $term = trim($term);
            
            // Only search if it looks like a keyword (contains spaces or is a single concept)
            if (empty($term)) {
                continue;
            }
            
            // Search Reddit for this term
            $search_results = $this->search_reddit($term);
            if (!empty($search_results)) {
                $topics = array_merge($topics, $search_results);
            }
        }
        
        return $topics;
    }
    
    private function search_reddit($query) {
        $topics = array();
        
        // Search across multiple relevant subreddits
        $search_subreddits = array('all', 'technology', 'news', 'worldnews', 'business');
        
        foreach ($search_subreddits as $subreddit) {
            $url = "https://www.reddit.com/r/{$subreddit}/search.json";
            $url .= "?q=" . urlencode($query);
            $url .= "&sort=hot&t=week&limit=10";
            
            $response = wp_remote_get($url, array(
                'headers' => array(
                    'User-Agent' => 'WordPress AI Auto Poster Bot 1.0'
                ),
                'timeout' => 15
            ));
            
            if (is_wp_error($response)) {
                continue;
            }
            
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);
            
            if (isset($data['data']['children']) && !empty($data['data']['children'])) {
                foreach ($data['data']['children'] as $post) {
                    $post_data = $post['data'];
                    
                    // Skip if already processed
                    $title = sanitize_text_field($post_data['title']);
                    $existing = array_filter($topics, function($topic) use ($title) {
                        return $topic['topic'] === $title;
                    });
                    
                    if (!empty($existing)) {
                        continue;
                    }
                    
                    $topics[] = array(
                        'topic' => $title,
                        'keywords' => $this->extract_keywords($post_data['title'] . ' ' . $query),
                        'trend_score' => min(100, max(20, $post_data['ups'] / 5)), // Higher base score for search results
                        'source' => 'reddit_search_' . $query
                    );
                }
                
                // Only search first subreddit if we found results
                if (!empty($topics)) {
                    break;
                }
            }
        }
        
        return array_slice($topics, 0, 10);
    }
    
    private function get_rss_topics() {
        $rss_feeds = get_option('ai_auto_poster_rss_feeds', '');
        
        if (empty($rss_feeds)) {
            return array();
        }
        
        $feeds = explode("\n", $rss_feeds);
        $topics = array();
        
        foreach ($feeds as $feed_url) {
            $feed_url = trim($feed_url);
            if (empty($feed_url)) continue;
            
            $rss = fetch_feed($feed_url);
            
            if (!is_wp_error($rss)) {
                $items = $rss->get_items(0, 10);
                
                foreach ($items as $item) {
                    $topics[] = array(
                        'topic' => sanitize_text_field($item->get_title()),
                        'keywords' => $this->extract_keywords($item->get_title() . ' ' . $item->get_description()),
                        'trend_score' => 60,
                        'source' => 'rss'
                    );
                }
            }
        }
        
        return $topics;
    }
    
    private function extract_keywords($text) {
        // Simple keyword extraction
        $text = strtolower($text);
        $text = preg_replace('/[^a-z0-9\s]/', '', $text);
        
        // Remove common stop words
        $stop_words = array('the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should');
        
        $words = explode(' ', $text);
        $keywords = array();
        
        foreach ($words as $word) {
            $word = trim($word);
            if (strlen($word) > 3 && !in_array($word, $stop_words)) {
                $keywords[] = $word;
            }
        }
        
        return implode(', ', array_slice(array_unique($keywords), 0, 10));
    }
    
    private function store_topics($topics) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'ai_auto_poster_topics';
        $stored_count = 0;
        
        foreach ($topics as $topic_data) {
            // Check if topic already exists (check last 7 days to avoid duplicates)
            $existing = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM $table_name WHERE topic = %s AND created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)",
                $topic_data['topic']
            ));
            
            if (!$existing) {
               $result = $wpdb->insert(
    $table_name,
    array(
        'topic' => $topic_data['topic'],
        'keywords' => $topic_data['keywords'],
        'trend_score' => $topic_data['trend_score'],
        'status' => 'pending',
        'created_at' => current_time('mysql')
    ),
    array('%s', '%s', '%d', '%s', '%s')
);
                
                if ($result) {
                    $stored_count++;
                }
            }
        }
        
        return $stored_count;
    }
}
<?php

class AI_Auto_Poster {
    
    private $topic_finder;
    private $content_generator;
    private $admin_settings;
    
    public function __construct() {
        $this->topic_finder = new AI_Topic_Finder();
        $this->content_generator = new AI_Content_Generator();
        $this->admin_settings = new AI_Auto_Poster_Admin_Settings();
    }
    
    public function run() {
        // Schedule cron jobs if enabled
        if (get_option('ai_auto_poster_enabled')) {
            $this->schedule_cron_jobs();
        }
        
        // Hook cron events
        add_action('ai_auto_poster_find_topics_cron', array($this, 'find_topics_cron'));
        add_action('ai_auto_poster_create_posts_cron', array($this, 'create_posts_cron'));
    }
    
    public function schedule_cron_jobs() {
        // Schedule topic finding
        $topic_frequency = get_option('ai_auto_poster_topic_frequency', 'hourly');
        if (!wp_next_scheduled('ai_auto_poster_find_topics_cron')) {
            wp_schedule_event(time(), $topic_frequency, 'ai_auto_poster_find_topics_cron');
        }
        
        // Schedule post creation
        $post_frequency = get_option('ai_auto_poster_post_frequency', 'twicedaily');
        if (!wp_next_scheduled('ai_auto_poster_create_posts_cron')) {
            wp_schedule_event(time(), $post_frequency, 'ai_auto_poster_create_posts_cron');
        }
    }
    
    public function find_topics_cron() {
        if (!get_option('ai_auto_poster_enabled')) {
            return;
        }
        
        $this->topic_finder->find_topics();
    }
    
    public function create_posts_cron() {
        if (!get_option('ai_auto_poster_enabled')) {
            return;
        }
        
        $this->create_posts_from_topics();
    }
    
    public function create_posts_from_topics() {
        global $wpdb;
        
        $posts_per_session = get_option('ai_auto_poster_posts_per_session', 1);
        $table_name = $wpdb->prefix . 'ai_auto_poster_topics';
        
        // Get best unused topics
        $topics = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE status = 'pending' ORDER BY trend_score DESC LIMIT %d",
            $posts_per_session
        ));
        
        if (empty($topics)) {
            return false;
        }
        
        $posts_created = 0;
        
        foreach ($topics as $topic) {
            $post_id = $this->create_post_from_topic($topic);
            
            if ($post_id) {
                // Mark topic as used
                $wpdb->update(
                    $table_name,
                    array('status' => 'used', 'used_at' => current_time('mysql')),
                    array('id' => $topic->id)
                );
                $posts_created++;
            }
        }
        
        return $posts_created > 0;
    }
    
    private function create_post_from_topic($topic) {
        // Generate content
        $content_data = $this->content_generator->generate_content($topic->topic, $topic->keywords);
        
        if (!$content_data) {
            return false;
        }
        
        // Prepare post data
        $post_data = array(
            'post_title' => $content_data['title'],
            'post_content' => $content_data['content'],
            'post_status' => get_option('ai_auto_poster_post_status', 'draft'),
            'post_author' => get_option('ai_auto_poster_author_id', get_current_user_id()),
            'post_type' => get_option('ai_auto_poster_post_type', 'post')
        );
        
        // Insert post
        $post_id = wp_insert_post($post_data);
        
        if (is_wp_error($post_id)) {
            return false;
        }
        
        // Add to categories
        $categories = get_option('ai_auto_poster_categories', array());
        if (!empty($categories)) {
            wp_set_post_categories($post_id, $categories);
        }
        
        // Add featured image if enabled
        if (get_option('ai_auto_poster_add_featured_image') && !empty($content_data['featured_image'])) {
            $image_data = $content_data['featured_image'];
            // Handle both array and string formats
            $image_url = is_array($image_data) ? $image_data['url'] : $image_data;
            $this->set_featured_image($post_id, $image_url, $content_data['title']);
        }
        
        return $post_id;
    }
    
    private function set_featured_image($post_id, $image_url, $alt_text) {
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        
        // Download image
        $tmp = download_url($image_url);
        
        if (is_wp_error($tmp)) {
            return false;
        }
        
        // Get file info
        $file_array = array(
            'name' => basename($image_url) . '.jpg',
            'tmp_name' => $tmp
        );
        
        // Upload to media library
        $id = media_handle_sideload($file_array, $post_id, $alt_text);
        
        if (is_wp_error($id)) {
            @unlink($tmp);
            return false;
        }
        
        // Set as featured image
        set_post_thumbnail($post_id, $id);
        
        return $id;
    }
    
    public function deactivate() {
        // Clear cron jobs
        wp_clear_scheduled_hook('ai_auto_poster_find_topics_cron');
        wp_clear_scheduled_hook('ai_auto_poster_create_posts_cron');
    }
    
    public static function activate() {
        global $wpdb;
        
        // Create topics table
        $table_name = $wpdb->prefix . 'ai_auto_poster_topics';
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            topic varchar(255) NOT NULL,
            keywords text,
            trend_score int DEFAULT 0,
            status varchar(20) DEFAULT 'pending',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            used_at datetime NULL,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Set default options
        $defaults = array(
            'ai_auto_poster_model' => 'gpt-3.5-turbo',
            'ai_auto_poster_word_count' => '800',
            'ai_auto_poster_tone' => 'professional',
            'ai_auto_poster_post_status' => 'draft',
            'ai_auto_poster_author_id' => get_current_user_id(),
            'ai_auto_poster_topic_frequency' => 'hourly',
            'ai_auto_poster_post_frequency' => 'twicedaily',
            'ai_auto_poster_posts_per_session' => '1',
            'ai_auto_poster_subreddits' => 'technology,blockchain,innovation',
            'ai_auto_poster_min_trend_score' => '10',
            'ai_auto_poster_add_featured_image' => '1',
            'ai_auto_poster_add_inline_images' => '0',
            'ai_auto_poster_images_per_post' => '2',
            'ai_auto_poster_enabled' => '1'
        );
        
        foreach ($defaults as $option => $value) {
            if (get_option($option) === false) {
                add_option($option, $value);
            }
        }
    }
    
    public static function deactivate_plugin() {
        // Clear scheduled events
        wp_clear_scheduled_hook('ai_auto_poster_find_topics_cron');
        wp_clear_scheduled_hook('ai_auto_poster_create_posts_cron');
    }
    
    public static function uninstall() {
        global $wpdb;
        
        // Remove database table
        $table_name = $wpdb->prefix . 'ai_auto_poster_topics';
        $wpdb->query("DROP TABLE IF EXISTS $table_name");
        
        // Remove all plugin options
        $options = array(
            'ai_auto_poster_openai_api_key',
            'ai_auto_poster_news_api_key',
            'ai_auto_poster_model',
            'ai_auto_poster_max_tokens',
            'ai_auto_poster_word_count',
            'ai_auto_poster_tone',
            'ai_auto_poster_post_status',
            'ai_auto_poster_author_id',
            'ai_auto_poster_categories',
            'ai_auto_poster_post_type',
            'ai_auto_poster_subreddits',
            'ai_auto_poster_rss_feeds',
            'ai_auto_poster_custom_keywords',
            'ai_auto_poster_excluded_keywords',
            'ai_auto_poster_min_trend_score',
            'ai_auto_poster_topic_frequency',
            'ai_auto_poster_post_frequency',
            'ai_auto_poster_posts_per_session',
            'ai_auto_poster_enabled',
            'ai_auto_poster_add_featured_image',
            'ai_auto_poster_unsplash_api_key',
            'ai_auto_poster_pexels_api_key',
            'ai_auto_poster_add_inline_images',
            'ai_auto_poster_images_per_post'
        );
        
        foreach ($options as $option) {
            delete_option($option);
        }
    }
}


<?php
/**
 * Plugin Name: AI Auto Poster
 * Plugin URI: https://yourwebsite.com
 * Description: Automatically finds trending topics and creates posts using AI
 * Version: 1.0.0
 * Author: Your Name
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('AI_AUTO_POSTER_VERSION', '1.0.0');
define('AI_AUTO_POSTER_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('AI_AUTO_POSTER_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include required files
require_once AI_AUTO_POSTER_PLUGIN_DIR . 'includes/class-ai-auto-poster.php';
require_once AI_AUTO_POSTER_PLUGIN_DIR . 'includes/class-topic-finder.php';
require_once AI_AUTO_POSTER_PLUGIN_DIR . 'includes/class-content-generator.php';
require_once AI_AUTO_POSTER_PLUGIN_DIR . 'includes/class-admin-settings.php';

// Initialize the plugin
function ai_auto_poster_init() {
    $plugin = new AI_Auto_Poster();
    $plugin->run();
}
add_action('plugins_loaded', 'ai_auto_poster_init');

// Activation hook
register_activation_hook(__FILE__, 'ai_auto_poster_activate');
function ai_auto_poster_activate() {
    AI_Auto_Poster::activate();
    
    // Schedule cron job
    if (!wp_next_scheduled('ai_auto_poster_find_topics_cron')) {
        wp_schedule_event(time(), 'hourly', 'ai_auto_poster_find_topics_cron');
    }
    
    if (!wp_next_scheduled('ai_auto_poster_create_posts_cron')) {
        wp_schedule_event(time(), 'twicedaily', 'ai_auto_poster_create_posts_cron');
    }
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'ai_auto_poster_deactivate');
function ai_auto_poster_deactivate() {
    wp_clear_scheduled_hook('ai_auto_poster_find_topics');
    wp_clear_scheduled_hook('ai_auto_poster_create_posts');
}
    // test code
// Temporary test - ADD THIS
// add_action('admin_init', function() {
//     if (isset($_GET['test_add_topic']) && current_user_can('manage_options')) {
//         global $wpdb;
//         $table_name = $wpdb->prefix . 'ai_auto_poster_topics';
        
//         $result = $wpdb->insert(
//             $table_name,
//             array(
//                 'topic' => 'Test Blockchain Topic - ' . date('Y-m-d H:i:s'),
//                 'keywords' => 'blockchain, cryptocurrency, technology, innovation',
//                 'trend_score' => 85,
//                 'status' => 'pending',
//                 'created_at' => current_time('mysql')
//             ),
//             array('%s', '%s', '%d', '%s', '%s')
//         );
        
//         if ($result) {
//             wp_redirect(admin_url('options-general.php?page=ai-auto-poster&test_success=1'));
//         } else {
//             wp_die('Error: ' . $wpdb->last_error);
//         }
//         exit;
//     }
    
//     if (isset($_GET['test_success'])) {
//         add_action('admin_notices', function() {
//             echo '<div class="notice notice-success is-dismissible"><p><strong>Success!</strong> Test topic added. Check the Status tab.</p></div>';
//         });
//     }
// });
//      test code
?>
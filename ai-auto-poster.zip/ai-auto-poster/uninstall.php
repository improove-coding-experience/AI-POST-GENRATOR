<?php
/**
 * Uninstall script for AI Auto Poster plugin
 */

// If uninstall not called from WordPress, then exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

global $wpdb;

// Delete database table
$table_name = $wpdb->prefix . 'ai_auto_poster_topics';
$wpdb->query("DROP TABLE IF EXISTS $table_name");

// Delete all plugin options
$options_to_delete = array(
    'ai_auto_poster_enabled',
    'ai_auto_poster_openai_api_key',
    'ai_auto_poster_news_api_key',
    'ai_auto_poster_unsplash_api_key',
    'ai_auto_poster_model',
    'ai_auto_poster_max_tokens',
    'ai_auto_poster_word_count',
    'ai_auto_poster_tone',
    'ai_auto_poster_post_status',
    'ai_auto_poster_author_id',
    'ai_auto_poster_categories',
    'ai_auto_poster_post_type',
    'ai_auto_poster_subreddits',
    'ai_auto_poster_rss_feeds',
    'ai_auto_poster_custom_keywords',
    'ai_auto_poster_excluded_keywords',
    'ai_auto_poster_min_trend_score',
    'ai_auto_poster_topic_frequency',
    'ai_auto_poster_post_frequency',
    'ai_auto_poster_posts_per_session',
    'ai_auto_poster_add_featured_image'
);

foreach ($options_to_delete as $option) {
    delete_option($option);
}

// Clear any remaining scheduled hooks
wp_clear_scheduled_hook('ai_auto_poster_find_topics');
wp_clear_scheduled_hook('ai_auto_poster_create_posts');
?>